package Model;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Objects;

public class myLinkedList<T> {


    //Define Node_NotUse<T> as inner class
    private class Node<T> {

        private T data;
        private Node<T> link;

        public Node() {

            this.data = null;
            this.link = null;

        }

        public Node(T typeData, Node<T> typeLink) {

            this.data = typeData;
            this.link = typeLink;
        }// End of inner class


        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Node<?> node = (Node<?>) o;
            return data.equals(node.data);
        }

        @Override
        public int hashCode() {
            return Objects.hash(data);
        }
    }

    //Define instance variable "head"
    private Node<T> head;

    //Default myLinkedList constructor
    public myLinkedList() {
        head = null;
    }


    public void addToStart(T data) {

        head = new Node<T>(data, head);

        //System.out.println("====> Head: " + head.hashCode() + " [data]: " + head.getWord());
    }

    public boolean deleteHeadNode() {

        if (head != null) {

            head = head.link;
            return true;
        } else {

            return false;
        }
    }


    public boolean insertOneNode(T targetData, Boolean isInsertAfter, T newdata){

        if ( isInsertAfter == null){

            System.out.println("Please specify \"isInsertAfter\" is True or False!");
            return false;
        }


        //Prepare a newNode for insert
        Node<T> newNode;

        //Insert newData into before or after head Node
        if (head != null && head.data.equals(targetData)){

            if (isInsertAfter){
                //Insert after head
                newNode = new Node<>(newdata, head.link);
                head.link  = newNode;

            }else{
                // Insert before head
                newNode = new Node<>(newdata, head);
                head = newNode;

            }

            return true;
        }

        Node<T> position = head;
        Node<T> pre_position = head;

        while(position !=null){

            if (position.data.equals(targetData)){
                if (isInsertAfter) {
                    //Insert after head
                    newNode = new Node<>(newdata, position.link);
                    position.link = newNode;

                    return true;

                } else {
                    // Insert before head
                    newNode = new Node<>(newdata, position);
                    pre_position.link = newNode;

                    return true;
                }
            }else{

                pre_position = position;
                position = position.link;
            }

        }
        return false;
    }



    public boolean removeOneNode(T anotherdata){

        if (head != null && head.data.equals(anotherdata)){

            return  deleteHeadNode();

        }

        Node<T> position = head;
        Node<T> pre_position = head;

        while(position != null){

            if ( position.data.equals(anotherdata)){

                //found the node then bypass the node
                pre_position.link = position.link;
                position = position.link;
                return  true;

            }
            pre_position = position;
            position = pre_position.link;

        }

        return false;

    }



    public int size() {

        int count = 0;
        Node<T> position = head;

        while (position != null) {

            count++;
            position = position.link;
        }
        return count;
    }

    public boolean contains(T anotherData) {

        Node<T> position = head;

        while (position != null) {

            if (position.data.equals(anotherData)) {

                return true;
            }
            position = position.link;

        }
        return false;

    }

    public void printList() {

        Node<T> position = head;
        while (position != null) {

            System.out.println(position.data);

            position = position.link;

        }
    }

    public void printToFile(String filename, boolean isAppend) {
        PrintWriter writer = null;


        try {
            if (isAppend) {

                writer = new PrintWriter(new FileOutputStream(filename, isAppend));

            } else {

                writer = new PrintWriter(new FileOutputStream(filename));
            }


            if (writer != null) {

                Node<T> position = head;
                while (position != null) {
                    System.out.println("Write word " + position.data + " to " + filename);
                    writer.println(position.data);
                    position = position.link;

                }
            }

            writer.close();
        } catch (FileNotFoundException e) {

            System.out.println("Errors: Can't write to " + filename);
            e.printStackTrace();

        }


    }

    public boolean isEmpty() {

        return (head == null);
    }

    public void clear() {

        head = null;
    }

}
