import Model.myLinkedList;
import com.sun.org.apache.xerces.internal.impl.xs.SchemaNamespaceSupport;

import javax.swing.plaf.synth.SynthTextAreaUI;
import java.io.*;
import java.util.Scanner;

public class Main {

    private  static myLinkedList<String> mylinkList = new myLinkedList<String>();

    private static void Menu(){

        System.out.println("\nSelect [1]: Print default text file\n" +
                "Select [2]: Init a LinkedList\n" +
                "Select [3]: Remove head node from the LinkedList\n" +
                "Select [4]: Remove any one node(head node included) from the Linkedlist\n" +
                "Select [5]: Insert one NEW node into the LinkedList before or after one target node\n" +
                "Select [6]: Write modified LinkedList to output.txt\n" +
                "Select [0]: Quit"+
                "\n");
    }

    public static void  goToFrontDesk(){

        int select;

        do{
            Menu();
            System.out.print("Please select: ");
            Scanner sc = new Scanner(System.in);
            select = sc.nextInt();

            switch(select){

                case 1:
                    printTextFile();
                    break;

                case 2:
                    initLinkedList();
                    break;
                case 3:
                    removeHeadNode();
                    break;

                case 4:
                    System.out.print("Please specify which node should be removed: ");
                    Scanner newSC = new Scanner(System.in);
                    String data = newSC.next();
                    if(!data.isEmpty()) {
                        removeAnyOneNode(data);
                    }else {

                        System.out.println("Invalid input! Please select again!");
                    }
                    break;

                case 5:
                    //insertOneNode();

                case 6:
                    //writeToFile();

                case 0:
                    System.out.println("Program finished!");
                    System.exit(0);


            }
        }while(select !=0);




    }

    private static void printTextFile(){

        Scanner sc = null;
        try {
            sc = new Scanner(new FileInputStream("myText.txt"));


            while (sc.hasNext()) {
                String word = sc.next();
                System.out.println("File Text: " + word);
            }
        }catch (IOException e){

            e.printStackTrace();
        }


    }

    private static void initLinkedList(){

        Scanner sc = null;
        try {
            sc = new Scanner(new FileInputStream("myText.txt"));


            while (sc.hasNext()) {
                String word = sc.next();
                //System.out.println("File Text: " + word);
                mylinkList.addToStart(word);
            }

            System.out.println("Init LinkedList finished");
            mylinkList.printList();

        }catch (IOException e){

            e.printStackTrace();
        }

    }

    private static void removeHeadNode(){

        if(mylinkList.deleteHeadNode()){

            System.out.println("Head node deleted!");
            mylinkList.printList();

        }

    }

    private static void  removeAnyOneNode(String nodeData){

        if (mylinkList.removeOneNode(nodeData)){

            System.out.println("Remove " + nodeData+ " successfully!");
            mylinkList.printList();
        }else{

            System.out.println("Remove " + nodeData+ " failed!");
        }

    }

    public static void main(String[] args) {

        goToFrontDesk();


    }


//
//         myLinkedList<String> mylinkList = new myLinkedList<String>();
//
//        try {
//            Scanner sc = new Scanner(new FileInputStream("myText.txt"));
//            while(sc.hasNext()) {
//                String word = sc.next();
//                //System.out.println("Add " + word + " into LinkedList");
//                mylinkList.addToStart(word);
//            }
//
////            if(mylinkList.size()>0)  {
////                //mylinkList.printList();
////                mylinkList.printToFile("myOutputFile.txt", true);
////
////
////            }else if (mylinkList.isEmpty()){
////
////                System.out.println("LinkedList is empty! Nothing to be printed!");
////            }else{
////
////                System.out.println("Unknown errors in LinkedList");
////            }
//
//
//           if ( mylinkList.removeOneNode("word-25")){
//               System.out.println("\n===> Remove Successful!");
//               mylinkList.printList();
//               //mylinkList.size();
//
//           }else{
//
//               System.out.println("\nxxx - Remove Failed! - xxx");
//
//           }
//
//
//           if (mylinkList.insertOneNode("word-24",false,"word-ZHY")){
//
//               System.out.println("\n===> Insert Successful!");
//               mylinkList.printList();
//           }else{
//
//               System.out.println("\nxxx - Insert Failed! - xxx");
//           }
//
//
//
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        }
//
//    }
}
