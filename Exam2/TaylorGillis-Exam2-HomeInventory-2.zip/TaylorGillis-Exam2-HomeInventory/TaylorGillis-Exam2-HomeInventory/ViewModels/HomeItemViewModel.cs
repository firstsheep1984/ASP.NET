﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace TaylorGillis_Exam2_HomeInventory.ViewModels
{
    public class HomeItemViewModel
    {
        [Required]
        [StringLength(100, ErrorMessage = "You must enter a serial number.")]
        [Display(Name = "Serial Number")]
        public string SerialNumber { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "You must enter a model.")]
        public string Model { get; set; }

        [Required]
        [StringLength(255, ErrorMessage = "You must enter an item description.")]
        public string Description { get; set; }

        [Required]
        public HttpPostedFileBase Photo { get; set; }

        [Required]
        [StringLength(255)]
        [Display(Name = "Location in Home")]
        public string Location { get; set; }

        [Required]
        [StringLength(255)]
        [Display(Name = "Purchase Location")]
        public string PurchaseLocation { get; set; }

        [Required]
        [Display(Name = "Purchase Date")]
        public DateTime PurchaseDate { get; set; }

        [Required]
        public float Cost { get; set; }
    }
}