﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using TaylorGillis_Exam2_HomeInventory.Models;
using TaylorGillis_Exam2_HomeInventory.ViewModels;
using TaylorGillis_Exam2_HomeInventory.Helpers;
using PagedList;

namespace TaylorGillis_Exam2_HomeInventory.Controllers
{
    public class HomeItemsController : Controller
    {
        private InventoryDbContext db = new InventoryDbContext();

        // GET: HomeItems
        public ViewResult Index(string sortDir, string sortOrder, int? page)
        {
            ViewBag.sortOrder = (sortOrder == null ? "asc" : sortOrder);
            ViewBag.sortDir = sortDir;
            sortOrder = sortOrder + "_" + sortDir;

            var items = db.HomeItems.Include(h => h.Location).Include(h => h.PurchaseInfo);

            items.OrderBy(i => i.Description);

            switch (sortOrder.ToLower())
            {
                case "desc_asc":
                    items = items.OrderBy(i => i.Description);
                    break;
                case "desc_desc":
                    items = items.OrderByDescending(i => i.Description);
                    break;
                case "model_asc":
                    items = items.OrderBy(i => i.Model);
                    break;
                case "model_desc":
                    items = items.OrderByDescending(i => i.Model);
                    break;
                case "serial_asc":
                    items = items.OrderBy(i => i.SerialNumber);
                    break;
                case "serial_desc":
                    items = items.OrderByDescending(i => i.SerialNumber);
                    break;
                case "loc_asc":
                    items = items.OrderBy(i => i.Location.Name);
                    break;
                case "loc_desc":
                    items = items.OrderByDescending(i => i.Location.Name);
                    break;
                default:
                    items = items.OrderBy(i => i.Description);
                    break;
            }

            return View(items.ToPagedList(page ?? 1, 3));
        }

        // GET: HomeItems/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HomeItem homeItem = db.HomeItems.Include(h => h.Location).Include(h => h.PurchaseInfo).Where(h => h.Id == id).FirstOrDefault();
            if (homeItem == null)
            {
                return HttpNotFound();
            }
            return View(homeItem);
        }

        // GET: HomeItems/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: HomeItems/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(HomeItemViewModel homeItemViewModel)
        {
            if (ModelState.IsValid)
            {
                Location newLoc = db.Locations.Where(loc => loc.Name == homeItemViewModel.Location).FirstOrDefault();
                if (newLoc == null)
                    newLoc = new Location(homeItemViewModel.Location);

                HomeItem newItem = new HomeItem
                {
                    SerialNumber = homeItemViewModel.SerialNumber,
                    Model = homeItemViewModel.Model,
                    Description = homeItemViewModel.Description,
                    Photo = ImageConverter.ByteArrayFromPostedFile(homeItemViewModel.Photo),
                    Location = newLoc,
                    PurchaseInfo = new PurchaseInfo(homeItemViewModel.PurchaseDate, homeItemViewModel.PurchaseLocation, homeItemViewModel.Cost)
                };

                db.HomeItems.Add(newItem);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(homeItemViewModel);
        }

        // GET: HomeItems/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HomeItem homeItem = db.HomeItems.Find(id);
            if (homeItem == null)
            {
                return HttpNotFound();
            }
            return View(homeItem);
        }

        // POST: HomeItems/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,SerialNumber,Model,Description,Photo")] HomeItem homeItem)
        {
            if (ModelState.IsValid)
            {
                db.Entry(homeItem).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(homeItem);
        }

        // GET: HomeItems/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HomeItem homeItem = db.HomeItems.Find(id);
            if (homeItem == null)
            {
                return HttpNotFound();
            }
            return View(homeItem);
        }

        // POST: HomeItems/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            HomeItem homeItem = db.HomeItems.Find(id);
            db.HomeItems.Remove(homeItem);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
