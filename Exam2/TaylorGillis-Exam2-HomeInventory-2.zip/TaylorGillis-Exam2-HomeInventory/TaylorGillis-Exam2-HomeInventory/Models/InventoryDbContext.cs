﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace TaylorGillis_Exam2_HomeInventory.Models
{
    public class InventoryDbContext : DbContext
    {
        public InventoryDbContext() : base("DefaultConnection")
        {
           // Database.SetInitializer(new MigrateDatabaseToLatestVersion<ApplicationDbContext, Configuration>());
        }
        public IDbSet<HomeItem> HomeItems { get; set; }
        public IDbSet<PurchaseInfo> PurchaseInfoes { get; set; }
        public IDbSet<Location> Locations { get; set; }

    }
}