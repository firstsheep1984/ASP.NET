﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Entity;
using TaylorGillis_Exam2_HomeInventory.Helpers;

namespace TaylorGillis_Exam2_HomeInventory.Models
{
    public class HomeItem
    {
        public int Id { get; set; }
        [StringLength(100)]
        [Display(Name = "Serial Number")]
        public string SerialNumber { get; set; }
        [StringLength(100)]
        public string Model { get; set; }
        [StringLength(255)]
        public string Description { get; set; }
        public byte[] Photo { get; set; }
        public Location Location { get; set; }
        [Display(Name = "Purchase Info")]
        public PurchaseInfo PurchaseInfo { get; set; }
    }
}