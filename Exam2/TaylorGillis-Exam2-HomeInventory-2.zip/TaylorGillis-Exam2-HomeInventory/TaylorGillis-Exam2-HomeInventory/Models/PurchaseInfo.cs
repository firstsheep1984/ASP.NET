﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace TaylorGillis_Exam2_HomeInventory.Models
{
    public class PurchaseInfo
    {
        public int Id { get; set; }
        public DateTime PurchaseDate { get; set; }
        [StringLength(255)]
        public string PurchaseLocation { get; set; }
        public float Cost { get; set; }

        public PurchaseInfo() { }

        public PurchaseInfo(DateTime purchaseDate, string purchaseLocation, float cost)
        {
            this.PurchaseDate = purchaseDate;
            this.PurchaseLocation = purchaseLocation;
            this.Cost = cost;
        }
    }
}