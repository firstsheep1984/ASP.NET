﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using PagedList;

using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HomeInventory.Helpers;
using HomeInventory.Infraestructure;
using HomeInventory.Models;
using HomeInventory.ViewModels;

namespace HomeInventory.Controllers
{
    public class HomeItemsController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: HomeItems
        public ActionResult Index()
        {
            var homeItems = db.HomeItems.Include(h => h.Location).Include(h => h.PurchaseInfo);
           
           return View(homeItems.ToList());
        }

        // GET: HomeItems/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HomeItem homeItem = db.HomeItems.Find(id);
            homeItem.Location = db.Locations.Find(homeItem.LocationId);
            homeItem.PurchaseInfo = db.PurchaseInfoes.Find(homeItem.PurchaseInfoId);
            //HomeItemViewModel model = new HomeItemViewModel();
            //model.Location = homeItem.Location;
            //model.Model = homeItem.Model;
            //model.Photo = homeItem.Photo;
            if (homeItem == null)
            {
                return HttpNotFound();
            }
            return View(homeItem);
        }

        // GET: HomeItems/Create
        public ActionResult Create()
        {

            ViewBag.LocationId = new SelectList(db.Locations, "LocationId", "Name");
            ViewBag.HomeItemId = new SelectList(db.PurchaseInfoes, "PurchaseInfoId", "Where");
            return View();
        }

        // POST: HomeItems/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult Create(HomeItemViewModel homeItemView)
        {
            if (ModelState.IsValid)
            {
                HomeItem homeItemDb = new HomeItem();
                //homeItemDb.HomeItemId = homeItemView.HomeItemId;
                homeItemDb.Model = homeItemView.Model;
                homeItemDb.SerialNumber = homeItemView.SerialNumber;
                homeItemDb.Location = homeItemView.Location;
                homeItemDb.LocationId = homeItemView.LocationId;
                PurchaseInfo info = new PurchaseInfo()
                {
   
                    Where = homeItemView.Where,
                    When = homeItemView.When,
                    Warranty = homeItemView.Warranty,
                    Price = homeItemView.Price
                };
                homeItemDb.PurchaseInfoId = info.PurchaseInfoId;
                homeItemDb.PurchaseInfo = info;
                homeItemDb.Description = homeItemView.Description;
                homeItemDb.Photo = ImageConverter.ByteArrayFromPostedFile(homeItemView.Photo);

                db.HomeItems.Add(homeItemDb);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.LocationId = new SelectList(db.Locations, "LocationId", "Name", homeItemView.LocationId);
            ViewBag.HomeItemId = new SelectList(db.PurchaseInfoes, "PurchaseInfoId", "Where", homeItemView.HomeItemId);
            return View(homeItemView);
        }

        // GET: HomeItems/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HomeItem homeItem = db.HomeItems.Find(id);
            if (homeItem == null)
            {
                return HttpNotFound();
            }
            ViewBag.LocationId = new SelectList(db.Locations, "LocationId", "Name", homeItem.LocationId);
            ViewBag.HomeItemId = new SelectList(db.PurchaseInfoes, "PurchaseInfoId", "Where", homeItem.HomeItemId);
            return View(homeItem);
        }

        // POST: HomeItems/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "HomeItemId,Model,SerialNumber,LocationId,PurchaseInfoId,Description,Photo")] HomeItem homeItem)
        {
            if (ModelState.IsValid)
            {
                db.Entry(homeItem).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.LocationId = new SelectList(db.Locations, "LocationId", "Name", homeItem.LocationId);
            ViewBag.HomeItemId = new SelectList(db.PurchaseInfoes, "PurchaseInfoId", "Where", homeItem.HomeItemId);
            return View(homeItem);
        }

        // GET: HomeItems/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HomeItem homeItem = db.HomeItems.Find(id);
            homeItem.Location = db.Locations.Find(homeItem.LocationId);
            homeItem.PurchaseInfo = db.PurchaseInfoes.Find(homeItem.PurchaseInfoId);
            if (homeItem == null)
            {
                return HttpNotFound();
            }
            return View(homeItem);
        }

        // POST: HomeItems/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            HomeItem homeItem = db.HomeItems.Find(id);
            
            db.HomeItems.Remove(homeItem);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
