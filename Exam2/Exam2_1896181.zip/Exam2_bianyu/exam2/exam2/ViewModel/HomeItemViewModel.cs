﻿using exam2.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace exam2.ViewModel
{
    public class HomeItemViewModel
    {
        [Key]
        public int HomeItemViewId { get; set; }

            public int HomeItemId { get; set; }

            public String Model { get; set; }
            public String SerialNumber { get; set; }

            public int LocationId { get; set; }
            public Location Location { get; set; }

            public String Description { get; set; }

            public HttpPostedFileBase Photo { get; set; }
            public DateTime When { get; set; }
            public String Where { get; set; }

            public String Warranty { get; set; }
            public Decimal Price { get; set; }
      
    }
}