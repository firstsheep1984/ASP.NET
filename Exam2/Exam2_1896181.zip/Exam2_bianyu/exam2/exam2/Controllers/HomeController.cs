﻿using exam2.Infraestructure;
using exam2.Models;
using exam2.ViewModel;
using System;
using System.Collections.Generic;
using exam2.Helpers;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System.Net;
using PagedList;
using System.Linq;
namespace exam2.Controllers
{
    public class HomeController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();
        public ActionResult Index(int? page)
        {

            var homeItems = db.HomeItems.Include(h => h.Location).Include(h=>h.PurchaseInfo).OrderBy(h=>h.Description);
            int pageSize = 2;
            int pageNumber = (page ?? 1);
            return View(homeItems.ToPagedList(pageNumber, pageSize));
         
            
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult Create()
        {
            ViewBag.LocationID = new SelectList(db.Locations, "LocationId", "Name");
            return View("HomeItemView");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(HomeItemViewModel homeItemViewModel)
        {
            if (ModelState.IsValid)
            {

                HomeItem homeItem = new HomeItem();
                homeItem.LocationId = homeItemViewModel.LocationId;
                homeItem.Description = homeItemViewModel.Description;
                homeItem.Model = homeItemViewModel.Model;
                homeItem.SerialNumber = homeItemViewModel.SerialNumber;
                homeItem.Photo = ImageConverter.ByteArrayFromPostedFile(homeItemViewModel.Photo);
                PurchaseInfo purchaseInfo = new PurchaseInfo();
                purchaseInfo.When = homeItemViewModel.When;
                purchaseInfo.Where = homeItemViewModel.Where;
                purchaseInfo.Warranty = homeItemViewModel.Warranty;
                purchaseInfo.Price = homeItemViewModel.Price;

                homeItem.PurchaseInfo = purchaseInfo;

                db.HomeItems.Add(homeItem);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.LocationID = new SelectList(db.Locations, "LocationId", "Name");
            return View(homeItemViewModel);
        }


     

    }
}