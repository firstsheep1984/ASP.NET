﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Test2Hongyu.Infraestructure;
using Test2Hongyu.Models;
using Test2Hongyu.ViewModels;

namespace Test2Hongyu.Controllers
{
    public class AllController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();
        // GET: All
        public ActionResult Index()
        {

            var homeList = db.HomeItems.ToList();
            var purchaseList = db.PurchaseInfoes.ToList();
            var locationList = db.Locations.ToList();



            var all = new All()
            {
                homeItemList = homeList,
                PurchaseInfoList = purchaseList,
                LocationList = locationList

            };


            //var All = db.HomeItems.Include(h => h.location).Include(h => h.purchaseInfo);
            return View(all);

            //return View(All);
        }

        // GET: All/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: All/Create
        public ActionResult Create()
        {
            //return View();

            var homeList = new List<HomeItem>();
            //var purchaseList = new List<PurchaseInfo>();
            //var locationList = new List<Location>();


            var all = new All()
            {
                homeItemList = homeList,
                //PurchaseInfoList = purchaseList,
                //LocationList = locationList

            };

            return View(all);
        }

        // POST: All/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: All/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: All/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: All/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: All/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
