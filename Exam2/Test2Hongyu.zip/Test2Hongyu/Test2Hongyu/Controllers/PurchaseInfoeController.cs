﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Test2Hongyu.Infraestructure;
using Test2Hongyu.Models;

namespace Test2Hongyu.Controllers
{
    public class PurchaseInfoeController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: PurchaseInfoe
        public ActionResult Index()
        {
            var purchaseInfoes = db.PurchaseInfoes.Include(p => p.homeItem);
            return View(purchaseInfoes.ToList());
        }

        // GET: PurchaseInfoe/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PurchaseInfo purchaseInfo = db.PurchaseInfoes.Find(id);
            if (purchaseInfo == null)
            {
                return HttpNotFound();
            }
            return View(purchaseInfo);
        }

        // GET: PurchaseInfoe/Create
        public ActionResult Create()
        {
            ViewBag.Id = new SelectList(db.HomeItems, "HomeItemId", "Model");
            return View();
        }

        // POST: PurchaseInfoe/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,When,Where,Warranty,Price")] PurchaseInfo purchaseInfo)
        {
            if (ModelState.IsValid)
            {
                db.PurchaseInfoes.Add(purchaseInfo);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Id = new SelectList(db.HomeItems, "HomeItemId", "Model", purchaseInfo.Id);
            return View(purchaseInfo);
        }

        // GET: PurchaseInfoe/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PurchaseInfo purchaseInfo = db.PurchaseInfoes.Find(id);
            if (purchaseInfo == null)
            {
                return HttpNotFound();
            }
            ViewBag.Id = new SelectList(db.HomeItems, "HomeItemId", "Model", purchaseInfo.Id);
            return View(purchaseInfo);
        }

        // POST: PurchaseInfoe/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,When,Where,Warranty,Price")] PurchaseInfo purchaseInfo)
        {
            if (ModelState.IsValid)
            {
                db.Entry(purchaseInfo).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Id = new SelectList(db.HomeItems, "HomeItemId", "Model", purchaseInfo.Id);
            return View(purchaseInfo);
        }

        // GET: PurchaseInfoe/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PurchaseInfo purchaseInfo = db.PurchaseInfoes.Find(id);
            if (purchaseInfo == null)
            {
                return HttpNotFound();
            }
            return View(purchaseInfo);
        }

        // POST: PurchaseInfoe/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            PurchaseInfo purchaseInfo = db.PurchaseInfoes.Find(id);
            db.PurchaseInfoes.Remove(purchaseInfo);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
