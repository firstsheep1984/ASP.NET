﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using Test2Hongyu.Models;

namespace Test2Hongyu.ViewModels
{
    public class All
    {
    
       public List<HomeItem> homeItemList { get ; set; }
       public List<PurchaseInfo> PurchaseInfoList{ get; set; }
        public List<Location> LocationList { get; set; }


    }
}