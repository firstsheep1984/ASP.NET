namespace Test2Hongyu.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Init : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.HomeItems",
                c => new
                    {
                        HomeItemId = c.Int(nullable: false),
                        Model = c.String(maxLength: 100),
                        SerialNumber = c.String(maxLength: 100),
                        locationId = c.Int(nullable: false),
                        purchaseInfoId = c.Int(nullable: false),
                        Description = c.String(nullable: false, maxLength: 255),
                        photo = c.Binary(),
                    })
                .PrimaryKey(t => t.HomeItemId)
                .ForeignKey("dbo.Locations", t => t.HomeItemId)
                .ForeignKey("dbo.PurchaseInfoes", t => t.HomeItemId)
                .Index(t => t.HomeItemId);
            
            CreateTable(
                "dbo.Locations",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 50),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.PurchaseInfoes",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        When = c.DateTime(),
                        Where = c.String(maxLength: 255),
                        Warranty = c.String(maxLength: 255),
                        Price = c.Double(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.HomeItems", "HomeItemId", "dbo.PurchaseInfoes");
            DropForeignKey("dbo.HomeItems", "HomeItemId", "dbo.Locations");
            DropIndex("dbo.HomeItems", new[] { "HomeItemId" });
            DropTable("dbo.PurchaseInfoes");
            DropTable("dbo.Locations");
            DropTable("dbo.HomeItems");
        }
    }
}
