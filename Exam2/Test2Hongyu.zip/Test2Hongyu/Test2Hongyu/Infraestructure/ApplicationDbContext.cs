﻿using Test2Hongyu.Migrations;
using Test2Hongyu.Models;
//using Test2Hongyu.ViewModels;
using System.Data.Entity;
using Test2Hongyu.ViewModels;

namespace Test2Hongyu.Infraestructure
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext() : base("DefaultConnection")
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<ApplicationDbContext, Configuration>());
        }

        //public IDbSet<HomeItem> HomeItem { get; set; }
        //public IDbSet<PurchaseInfo> PurchaseInfo { get; set; }
        //public IDbSet<Location> Location { get; set; }

        public System.Data.Entity.DbSet<Test2Hongyu.Models.HomeItem> HomeItems { get; set; }

        public System.Data.Entity.DbSet<Test2Hongyu.Models.Location> Locations { get; set; }

        public System.Data.Entity.DbSet<Test2Hongyu.Models.PurchaseInfo> PurchaseInfoes { get; set; }

        //public virtual DbSet<All> all { get; set; }


    }
}