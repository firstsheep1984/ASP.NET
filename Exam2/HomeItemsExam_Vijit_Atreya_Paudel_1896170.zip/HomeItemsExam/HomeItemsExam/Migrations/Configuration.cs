namespace HomeItemsExam.Migrations
{
    using System.Data.Entity.Migrations;
    using HomeItemsExam.Infraestructure;
    using HomeItemsExam.Models;

    internal sealed class Configuration : DbMigrationsConfiguration<HomeItemsExam.Infraestructure.ApplicationDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
        }
        protected override void Seed(ApplicationDbContext context)
        {
            context.Locations.AddOrUpdate(l => l.Name,
                new Location()
                {
                    Name = "Home Office"
                },
                new Location()
                {
                    Name = "Family Room"
                },
                new Location()
                {
                    Name = "Living Room"
                },
                new Location()
                {
                    Name = "Kitchen"
                },
                new Location()
                {
                    Name = "Master Bedroom"
                },
                new Location()
                {
                    Name = "Bedroom Two"
                },
                new Location()
                {
                    Name = "Bedroom Three"
                },
                new Location()
                {
                    Name = "Bathrooms"
                },
                new Location()
                {
                    Name = "Garage"
                },
                new Location()
                {
                    Name = "Attic"
                },
                new Location()
                {
                    Name = "Basement"
                },
                new Location()
                {
                    Name = "Other"
                }
           );
            context.SaveChanges();
            base.Seed(context);
        }
    }
}
