﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HomeInventory.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var controller = new HomeItemsController();
            controller.ControllerContext = new ControllerContext(this.ControllerContext.RequestContext, controller);
            return controller.Index();
        }
        public ActionResult Create()
        {
            var controller = new HomeItemsController();
            controller.ControllerContext = new ControllerContext(this.ControllerContext.RequestContext, controller);
            return controller.Create();
        }

    }
}